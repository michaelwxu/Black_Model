#' Black76
#'
#' This function calculate the option price from Black-76 Model (Black Model)
#' @param F Futures price
#' @param K Strike price
#' @param T Time to maturity, in year
#' @param r Continuous compound rate, default is 0
#' @param vol Volatility
#' @param type Option Type, C for Call, P for Put
#' @return Returns price calculated by Black's model
#' @keywords 
#' @export
#' @examples
#' Black76(F = 48.03, K = 50, T = 0.1423, r = 0, vol = 0.3, type = "C")

Black76 <- function(F, K, T, r = 0, vol, type="C"){
  d1 <- (log(F / K) + (r + vol ^ 2 / 2) * T) / (vol * sqrt(T))
  d2 <- d1 - vol * sqrt(T)
  # Calculate the price of the options
  # ref: https://en.wikipedia.org/wiki/Black_model
  if(type=="C"){
    res <- exp(-r * T) * (F * pnorm(d1) - K * pnorm(d2))
  }
  if(type=="P"){
    res <- exp(-r * T) * (K * pnorm(-d2) - F * pnorm(-d1))
  }
  return(res)
}
