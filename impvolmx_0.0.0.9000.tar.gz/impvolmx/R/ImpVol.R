#' ImpVol
#'
#' This function calculate Implied Vol using Bisection Method
#' @param F Futures price
#' @param K Strike price
#' @param T Time to maturity, in year
#' @param r Continuous compound rate, default is 0
#' @param mkt.price Price observed in the market
#' @param type Option Type, C for Call, P for Put
#' @return Returns implied volatility, backed out by plugging in 
#'        everything into Black model
#' @keywords 
#' @export
#' @examples
#' ImpVol(F = 48.03, K = 50, T = 0.1423, r = 0, mkt.price = 1.62, type = "C")

ImpVol <- function(F, K, T, r = 0, mkt.price, type){
 
  imp.vol <- 0.20
  imp.vol.up <- 1
  imp.vol.down <- 0.001
  count <- 0
  
  # The difference of 
  err <- Black76(F, K, T, r, imp.vol, type) - mkt.price 
  
  # Method: repeat until the difference is sufficiently small, or counter reaches 1000
  while(abs(err) > 1e-6 && count < 1000){
    if(err < 0){
      # price calculated by Black76 model < market observed price
      # adjust the imp.vol up
      imp.vol.down <- imp.vol
      imp.vol <- (imp.vol.up + imp.vol) / 2
    } else {
      # price calculated by Black76 model > market observed price
      # adjust the imp.vol down
      imp.vol.up <- imp.vol
      imp.vol <- (imp.vol.down + imp.vol) / 2
    }
    err <- Black76(F, K, T, r, imp.vol, type) - mkt.price 
    count <- count + 1
  }
  
  # Return NA if counter reaches 1000
  if(count == 1000){
    return(NA)
  } else {
    return (imp.vol)
  }
}