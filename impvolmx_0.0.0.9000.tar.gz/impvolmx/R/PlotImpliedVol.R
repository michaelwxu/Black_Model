#' PlotImpliedVol
#'
#' This function returns calculated implied volatility with plots 
#' for calls and puts on a same chart
#' @param df Dataframe that data frame contains 5 columns with name 
#'        "strike", "type", "optionPrice", "futurePrice", "time_to_expiry".
#'        if df does not contain column "r", the risk-free interest rate will be defaulted with 0.
#' @return Returns the same df as input, with an extra column 
#'        appended to the right, named "impVol" as culatedimplied volaility
#' @keywords 
#' @export
#' @examples
#' library(impvolmx)
#' data("Sample")  # this doesn't work on Michael's laptop.. 
#' df = data.frame(strike = c(50, 20, 40, 30), # the option strike in $
#'                 type = c("C", "P", "C", "P"), # either “c” for call option or “p” for a put option
#'                 optionPrice = c(1.62,0.01, 8.5, 0.1), # the option price in $
#'                 futurePrice = c(48.03, 48.03, 48.03, 48.03), # the price of the underlying futures in $
#'                 time_to_expiry = c(0.1423, 0.1423, 0.1423, 0.1423)) # the option time to expiry in year
#' plotImpliedVol(df)
plotImpliedVol <- function(df) {
  # Check if the columns are in place
  if (!"strike" %in% names(df)){
    stop("column 'strike' is missing!")
  }
  if (!"type" %in% names(df)){
    stop("column 'type' is missing!")
  }
  if (!"optionPrice" %in% names(df)){
    stop("column 'optionPrice' is missing!")
  }
  if (!"futurePrice" %in% names(df)){
    stop("column 'futurePrice' is missing!")
  }
  if (!"time_to_expiry" %in% names(df)){
    stop("column 'time_to_expiry' is missing!")
  }
  
  # vector to store implied vol calcualted:
  imp.vol <- rep(0, nrow(df))
  
  # Calculate implied vol
  for(i in 1 : nrow(df)){
    # Perform some checks on df
    if (!df$type[i] %in% c("C", "P")) {
      stop("Please check if option types are input correctly. Accepted values: C or P")
    }
    imp.vol[i] <- ImpVol(F = df$futurePrice[i], 
                         K = df$strike[i], 
                         T = df$time_to_expiry[i], 
                         r = ifelse("r" %in% names(df), df$r[i], 0), 
                         mkt.price = df$optionPrice[i], 
                         type = df$type[i])
  }
  
  df$impVol <- imp.vol
  # Separate the df for calls and puts, for plotting purpose
  df.c <- df[which(df$type == "C" & (!is.na(df$impVol))), ]
  df.p <- df[which(df$type == "P" & (!is.na(df$impVol))), ]
  
  # Now do the plotting
  plot.new()
  par(mfrow = c(1, 1))
  xrange <- range(df$strike[which(!is.na(df$impVol))])
  yrange <- range(df$impVol[which(!is.na(df$impVol))])
  plot(xrange, yrange, type = "n", main=c("Implied Volatility", "Calls vs Puts"), 
       cex.main = 0.8,
       xlab="Strike", 
       ylab="Implied Vol")
  # calls
  lines(x = df.c$strike, y = df.c$impVol, 
        type="b", 
        col = "blue", 
        pch = 21)  # circles
  # puts
  lines(x = df.p$strike, y = df.p$impVol, 
        type = "b", 
        col = "red", 
        pch = 22)  # squares
  legend("bottomleft", 
         cex = 0.8, 
         c("Call", "Put"), 
         lty = c(1, 1), 
         col = c("blue", "red"),
         pch = c(21, 22))
  return (df)
}